# MarsianPaint 1.0.0
A web drawing program made with gemini,built with Python (Flask) and JavaScript
## Features
Pencil, Eraser, and Bucket Fill (Simply Fill) tools

## How to run
1.Extract the archive
2.Run runmars.bat file,loading is very short
3.Program opens in browser
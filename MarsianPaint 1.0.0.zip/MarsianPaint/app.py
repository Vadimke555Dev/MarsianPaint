from flask import Flask, render_template, request
import webbrowser
import os
import base64

app = Flask(__name__)

if not os.path.exists('images'):
    os.makedirs('images')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/save', methods=['POST'])
def save_image():
    data = request.json['image']
    img_data = base64.b64decode(data.split(',')[1])
    
    filename = f"images/art_{len(os.listdir('images')) + 1}.png"
    with open(filename, 'wb') as f:
        f.write(img_data)
    
    return {"status": "success", "filename": filename}

if __name__ == '__main__':
    webbrowser.open("http://127.0.0.1:5000")
    app.run(port=5000)
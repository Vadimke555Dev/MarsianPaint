@echo off
py -m pip install flask
py app.py
pause
@echo off
title MarsianPaint 1.0.1
py app.py
pause
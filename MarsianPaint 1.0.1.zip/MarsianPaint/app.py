from flask import Flask
import webbrowser
from threading import Timer

app = Flask(__name__)

@app.route('/')
def index():
    return r'''
    <!DOCTYPE html>
    <html>
    <head>
        <title>MarsianPaint 1.0.1</title>
        <style>
            body { transition: 0.3s; font-family: sans-serif; margin: 0; display: flex; height: 100vh; overflow: hidden; background: #2d2d2d; }
            #sidebar { width: 250px; padding: 15px; border-right: 1px solid #555; display: flex; flex-direction: column; gap: 10px; overflow-y: auto; background: #222; color: white; z-index: 10; }
            #canvas-area { flex-grow: 1; display: flex; justify-content: center; align-items: center; background: #333; overflow: auto; }
            #canvas-container { transition: 0.1s; transform-origin: center; }
            canvas { background: white; cursor: crosshair; image-rendering: pixelated; display: block; box-shadow: 0 0 20px rgba(0,0,0,0.5); }
            button { padding: 8px; cursor: pointer; border: 1px solid #666; border-radius: 4px; background: #444; color: white; font-weight: bold; font-size: 11px; }
            .addon-box { border: 1px dashed #777; padding: 10px; margin-top: 10px; display: flex; flex-direction: column; gap: 5px; }
            .active { background: #28a745 !important; color: white !important; }
            .history-box { display: grid; grid-template-columns: 1fr 1fr; gap: 5px; }
            label { font-size: 10px; text-transform: uppercase; color: #aaa; }
        </style>
    </head>
    <body id="mainBody">
        <div id="sidebar">
            <div class="history-box">
                <button onclick="undo()">Undo</button>
                <button onclick="redo()">Redo</button>
            </div>
            <hr style="width:100%; border:0.5px solid #444">
            <button onclick="setTool('pencil')">Pencil</button>
            <button onclick="setTool('eraser')">Eraser</button>
            <button onclick="setTool('fill')">Bucket Fill</button>
            <input type="color" id="colorPicker" value="#000000">
            <input type="range" id="sizePicker" min="1" max="50" value="15">
            <div class="addon-box">
                <label>Addons Manager</label>
                <button id="btn-3D" onclick="toggleAddon('3D', this)">3D Pencil</button>
                <button id="btn-Soundout" onclick="toggleAddon('Soundout', this)">Soundout!</button>
                <button id="btn-Boogeyman" onclick="toggleAddon('Boogeyman', this)">Boogeyman</button>
                <button id="btn-Chocolaate" onclick="toggleAddon('Chocolaate', this)">Chocolaate</button>
                <button id="btn-Clay" onclick="toggleAddon('Clay', this)">Clay</button>
                <button id="btn-Iron" onclick="toggleAddon('Iron', this)">Iron</button>
            </div>
            <hr style="width:100%; border:0.5px solid #444">
            <button style="background:#dc3545" onclick="if(confirm('Clear?')) { pushState(); initCanvas(); }">Clear Canvas</button>
            <button style="background:#28a745" onclick="saveImage()">Save PNG</button>
            <label>Zoom</label>
            <input type="range" id="zoomPicker" min="0.5" max="5" step="0.1" value="1" oninput="updZoom()">
        </div>
        <div id="canvas-area">
            <div id="canvas-container"><canvas id="cv" width="800" height="600"></canvas></div>
        </div>
        <script>
            const cv = document.getElementById('cv');
            const ctx = cv.getContext('2d', {willReadFrequently: true});
            const container = document.getElementById('canvas-container');
            let draw = false;
            let tool = 'pencil';
            let activeAddons = { "3D": false, "Soundout": false, "Boogeyman": false, "Chocolaate": false, "Clay": false, "Iron": false };
            let undoStack = [];
            let redoStack = [];

            function initCanvas() { ctx.fillStyle = "white"; ctx.fillRect(0, 0, cv.width, cv.height); }
            initCanvas();

            function pushState() {
                if (undoStack.length > 25) undoStack.shift();
                undoStack.push(cv.toDataURL());
                redoStack = []; 
            }

            function undo() {
                if (undoStack.length > 0) {
                    redoStack.push(cv.toDataURL());
                    let img = new Image();
                    img.src = undoStack.pop();
                    img.onload = () => { ctx.clearRect(0,0,cv.width,cv.height); ctx.drawImage(img, 0, 0); };
                }
            }

            function redo() {
                if (redoStack.length > 0) {
                    undoStack.push(cv.toDataURL());
                    let img = new Image();
                    img.src = redoStack.pop();
                    img.onload = () => { ctx.clearRect(0,0,cv.width,cv.height); ctx.drawImage(img, 0, 0); };
                }
            }

            function toggleAddon(name, btn) {
                activeAddons[name] = !activeAddons[name];
                btn.classList.toggle('active');
            }

            function setTool(t) { tool = t; }

            cv.onmousedown = (e) => {
                pushState();
                draw = true;
                const rect = cv.getBoundingClientRect();
                const scale = rect.width / cv.width;
                const x = Math.round((e.clientX - rect.left) / scale);
                const y = Math.round((e.clientY - rect.top) / scale);
                if(activeAddons.Soundout) {
                    let audio = new (window.AudioContext || window.webkitAudioContext)();
                    let osc = audio.createOscillator();
                    let gain = audio.createGain();
                    osc.connect(gain); gain.connect(audio.destination);
                    osc.frequency.setValueAtTime(330, audio.currentTime);
                    gain.gain.setValueAtTime(0.05, audio.currentTime);
                    osc.start(); osc.stop(audio.currentTime + 0.05);
                }
                if(tool=='fill') { fill(x, y, document.getElementById('colorPicker').value); draw = false; }
                else { ctx.beginPath(); ctx.moveTo(x, y); }
            };

            cv.onmousemove = (e) => {
                if(!draw) return;
                const rect = cv.getBoundingClientRect();
                const scale = rect.width / cv.width;
                let x = (e.clientX - rect.left) / scale;
                let y = (e.clientY - rect.top) / scale;
                if(activeAddons.Boogeyman) { x += Math.random() * 20 - 10; y += Math.random() * 20 - 10; }
                
                const size = parseInt(document.getElementById('sizePicker').value);
                const color = document.getElementById('colorPicker').value;

                if(activeAddons.Iron && tool !== 'eraser') {
                    ctx.fillStyle = color;
                    ctx.strokeStyle = "#ffffff";
                    ctx.lineWidth = 1;
                    ctx.fillRect(x - size/2, y - size/2, size, size);
                    ctx.strokeRect(x - size/2, y - size/2, size, size);
                    ctx.fillStyle = "rgba(255,255,255,0.15)";
                    ctx.fillRect(x - size/2, y - size/2, size, size/3);
                    ctx.lineTo(x, y);
                    ctx.stroke();
                } else if(activeAddons.Clay && tool !== 'eraser') {
                    ctx.globalAlpha = 0.4;
                    for(let i=0; i<3; i++) {
                        let ox = x + (Math.random() * 4 - 2);
                        let oy = y + (Math.random() * 4 - 2);
                        ctx.lineWidth = size + (Math.random() * 4);
                        ctx.lineCap = 'round';
                        ctx.strokeStyle = color;
                        ctx.lineTo(ox, oy); ctx.stroke();
                        ctx.beginPath(); ctx.moveTo(ox, oy);
                    }
                    ctx.globalAlpha = 1.0;
                } else {
                    ctx.lineWidth = size;
                    ctx.lineCap = 'round';
                    ctx.strokeStyle = tool === 'eraser' ? '#ffffff' : color;
                    if(activeAddons["3D"] && tool !== 'eraser') {
                        ctx.shadowBlur = 10; ctx.shadowColor = 'rgba(0,0,0,0.5)';
                        ctx.shadowOffsetX = 4; ctx.shadowOffsetY = 4;
                    } else {
                        ctx.shadowBlur = 0; ctx.shadowOffsetX = 0; ctx.shadowOffsetY = 0;
                    }
                    ctx.lineTo(x, y);
                    ctx.stroke();
                }

                if(activeAddons.Chocolaate && tool !== 'eraser') {
                    for(let i=0; i<2; i++) {
                        const sx = x + (Math.random() * size * 2 - size);
                        const sy = y + (Math.random() * size * 2 - size);
                        ctx.fillStyle = color; ctx.beginPath();
                        ctx.arc(sx, sy, Math.random() * (size / 4), 0, Math.PI * 2); ctx.fill();
                    }
                }
            };

            cv.onmouseup = () => draw = false;

            function updZoom() { container.style.transform = `scale(${document.getElementById('zoomPicker').value})`; }
            function saveImage() { const link = document.createElement('a'); link.download = 'art.png'; link.href = cv.toDataURL("image/png"); link.click(); }

            function fill(startX, startY, color) {
                const imageData = ctx.getImageData(0, 0, cv.width, cv.height);
                const data = imageData.data;
                const pixelPos = (startY * cv.width + startX) * 4;
                const startR = data[pixelPos], startG = data[pixelPos+1], startB = data[pixelPos+2];
                const rgb = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(color);
                const fillR = parseInt(rgb[1],16), fillG = parseInt(rgb[2],16), fillB = parseInt(rgb[3],16);
                if (startR === fillR && startG === fillG && startB === fillB) return;
                const stack = [[startX, startY]];
                while (stack.length > 0) {
                    const [x, y] = stack.pop();
                    let i = (y * cv.width + x) * 4;
                    if (data[i] === startR && data[i+1] === startG && data[i+2] === startB) {
                        data[i] = fillR; data[i+1] = fillG; data[i+2] = fillB; data[i+3] = 255;
                        if (x > 0) stack.push([x - 1, y]); if (x < cv.width - 1) stack.push([x + 1, y]);
                        if (y > 0) stack.push([x, y - 1]); if (y < cv.height - 1) stack.push([x, y + 1]);
                    }
                }
                ctx.putImageData(imageData, 0, 0);
            }

            window.addEventListener('keydown', (e) => {
                if (e.ctrlKey && e.key === 'z') undo();
                if (e.ctrlKey && (e.key === 'y' || (e.ctrlKey && e.shiftKey && e.key === 'Z'))) redo();
            });
        </script>
    </body>
    </html>
    '''

def run_app():
    webbrowser.open_new("http://127.0.0.1:5000")

if __name__ == '__main__':
    Timer(1.5, run_app).start()
    app.run(port=5000)